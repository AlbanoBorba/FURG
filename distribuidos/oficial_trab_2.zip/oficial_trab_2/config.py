class Config:
    def __init__(self):
        self.this_machine = "192.168.1.107"
        self.rmi_machine_ip = "192.168.1.102"
        self.rmi_machine_port = 9090
        self.mq_machine_ip = "192.168.1.107"
        self.mq_machine_port = 5672
        self.ws_machine_ip = "192.168.1.104"
        self.ws_machine_port = 8080
        self.ts_machine_ip = "192.168.1.102"
        self.ts_machine_port = 8765
