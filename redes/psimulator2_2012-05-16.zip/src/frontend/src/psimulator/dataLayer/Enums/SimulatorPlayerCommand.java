package psimulator.dataLayer.Enums;

/**
 *
 * @author Martin Švihlík <svihlma1 at fit.cvut.cz>
 */
public enum SimulatorPlayerCommand {
    //PLAY,
    //STOP,
    FIRST, 
    LAST,
    PREVIOUS,
    NEXT;
}
