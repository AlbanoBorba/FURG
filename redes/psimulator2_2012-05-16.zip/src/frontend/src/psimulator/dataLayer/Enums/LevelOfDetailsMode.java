package psimulator.dataLayer.Enums;

/**
 *
 * @author Martin Švihlík <svihlma1 at fit.cvut.cz>
 */
public enum LevelOfDetailsMode {
    AUTO,
    MANUAL;
}
