package psimulator.dataLayer.Simulator;

/**
 *
 * @author Martin Švihlík <svihlma1 at fit.cvut.cz>
 */
public class ParseSimulatorEventException extends Exception{
    
    public ParseSimulatorEventException(){
        
    }
    
}
