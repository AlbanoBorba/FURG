package psimulator.logicLayer;

/**
 *
 * @author Martin Švihlík <svihlma1 at fit.cvut.cz>
 */
public interface ControllerFacade {
    
}
