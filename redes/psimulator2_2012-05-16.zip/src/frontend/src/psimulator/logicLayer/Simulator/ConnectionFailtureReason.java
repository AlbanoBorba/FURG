package psimulator.logicLayer.Simulator;

/**
 *
 * @author Martin Švihlík <svihlma1 at fit.cvut.cz>
 */
public enum ConnectionFailtureReason {
    SERVER_DISCONNECTED,
    SERVER_SENT_WRONG_OBJECT,
    TABLE_WITH_TELNET_NOT_RECIEVED,
}
