package psimulator.userInterface.SaveLoad;

/**
 *
 * @author Martin Švihlík <svihlma1 at fit.cvut.cz>
 */
public enum SaveLoadManagerUserReaction {
    DO_SAVE,
    DO_NOT_SAVE,
    CANCEL;
}
