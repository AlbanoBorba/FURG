package psimulator.userInterface.SimulatorEditor.DrawPanel.Enums;

/**
 *
 * @author Martin Švihlík <svihlma1 at fit.cvut.cz>
 */
public enum LevelOfDetail {
    LEVEL_1,
    LEVEL_2,
    LEVEL_3,
    LEVEL_4;
}
