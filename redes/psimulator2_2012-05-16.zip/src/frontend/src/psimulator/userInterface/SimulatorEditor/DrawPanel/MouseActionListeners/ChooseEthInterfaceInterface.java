package psimulator.userInterface.SimulatorEditor.DrawPanel.MouseActionListeners;

import shared.Components.EthInterfaceModel;

/**
 *
 * @author Martin Švihlík <svihlma1 at fit.cvut.cz>
 */
public interface ChooseEthInterfaceInterface {
    public void setChosenInterface(EthInterfaceModel ethInterface);
}
