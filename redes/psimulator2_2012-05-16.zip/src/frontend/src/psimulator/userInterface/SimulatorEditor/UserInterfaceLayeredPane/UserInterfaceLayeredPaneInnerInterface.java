package psimulator.userInterface.SimulatorEditor.UserInterfaceLayeredPane;

/**
 *
 * @author Martin Švihlík <svihlma1 at fit.cvut.cz>
 */
public interface UserInterfaceLayeredPaneInnerInterface {
    
    public void doFitToGraphSize();
    
}
