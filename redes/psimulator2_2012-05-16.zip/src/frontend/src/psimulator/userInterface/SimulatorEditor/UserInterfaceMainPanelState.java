package psimulator.userInterface.SimulatorEditor;

/**
 *
 * @author Martin Švihlík <svihlma1 at fit.cvut.cz>
 */
public enum UserInterfaceMainPanelState {
    WELCOME,
    EDITOR,
    SIMULATOR;
}

