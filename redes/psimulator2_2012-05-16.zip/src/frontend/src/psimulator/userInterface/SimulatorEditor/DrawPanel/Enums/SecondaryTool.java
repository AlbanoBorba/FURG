package psimulator.userInterface.SimulatorEditor.DrawPanel.Enums;

/**
 *
 * @author Martin Švihlík <svihlma1 at fit.cvut.cz>
 */
public enum SecondaryTool {
    ALIGN_TO_GRID,
    FIT_TO_SIZE; 
}
