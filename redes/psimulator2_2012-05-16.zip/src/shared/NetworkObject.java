/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package shared;

/**
 * interface marking all classes being transported through network/socket/ObjectOutpuStream ...
 * just for sure, that none one try to transport non-marked object
 * @author Martin Lukáš <lukasma1@fit.cvut.cz>
 */
public interface NetworkObject {
    
}
