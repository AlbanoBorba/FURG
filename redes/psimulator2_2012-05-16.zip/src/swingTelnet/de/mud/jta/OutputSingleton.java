

package de.mud.jta;

/**
 *
 * @author Martin Lukáš <lukasma1@fit.cvut.cz>
 */
public final class OutputSingleton {
    
    public static  DelegatePrintStream out ;
    public static  DelegatePrintStream err;
    
    
}
