import socket
import time
import os

HOST = ''
PORT = 1100
tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
orig = (HOST, PORT)
tcp.bind(orig)
tcp.listen(50)
con, cliente = tcp.accept()
print ("received connection:", cliente)
ha = Thread(target = handle, args = (con, ))
ha.start()
msg = con.recv(1024)
msg = msg.decode("utf-8")
print msg
msg = con.recv(1024)
msg = msg.decode("utf-8")
print msg
con.close()
